Looking Glass B7
To install, copy the files to their respective folders:


File							Folder
-----------------------------------------------------------------------------
looking-glass-client			/usr/local/bin/
looking-glass-client.desktop	/usr/local/share/applications/
looking-glass.svg				/usr/local/share/icons/hicolor/scalable/apps/


You can copy/paste the following commands:
----------------------------------------------------------------------------------------------
sudo cp ./looking-glass-client /usr/local/bin/
sudo cp ./looking-glass-client.desktop /usr/local/share/applications/
sudo cp ./looking-glass.svg /usr/local/share/icons/hicolor/scalable/apps/
